class list_radio:
    def fill():
       #{"name":"channel_radio ","kind":"p","country":"ps" ,"url":"url1","logo":"logo1"},
     _radio="الإذاعة "
     channels=[
              {"name":" قناة الشمس  ","kind":_radio,"country":"فلسطين" ,"url":"https://cdna.streamgates.net/Ashams/Live/icecast.audio","logo":"https://i.ytimg.com/vi/eOai_UbumlM/hqdefault.jpg"},
              
               {"name":"الناس ","kind":_radio,"country":"فلسطين" ,"url":"https://cdna.streamgates.net/RadioNas/Live-Audio/icecast.audio","logo":"https://is.gd/AOksLB"},
                {"name":"سوا ","kind":_radio,"country":"سوريا" ,"url":"http://192.99.8.192:3054/;stream.mp3/stream.mp3","logo":"https://is.gd/X8ZzXL"},
                 {"name":"محطة مصر ","kind":_radio,"country":"مصر" ,"url":"https://s3.radio.co/s9cb11828c/listen","logo":"https://cdn.webrad.io/images/logos/egyptradio-net/mahatet-masr.png"},
              {"name":" مكان  ","kind":"p","country":"فلسطين" ,"url":"https://is.gd/TioCKh","logo":"https://is.gd/qU4LGD"},
              ]

     return channels
