class list_Qkareem:
    def fill():
    # {"name":"channel_radio ","kind":"p","country":"ps" ,"url":"url1","logo":"logo1"},
     satellite_channel="القناة الفضائية" 
     _kareem="اذاعة"

     channels=[
              {"name":" قناة المجد للقران الكريم ","kind":_kareem,"country":"الحجاز" ,"url":"http://r1.tarat.com:8196/;","logo":"https://img.youm7.com/large/201903251226322632.jpg"},
               {"name":"لإذاعة القرآن الكريم من نابلس -  ","kind":_kareem ,"country":"فلسطين" ,"url":"http://www.quran-radio.org:8080/;stream.mp3","logo":"https://img.youm7.com/large/201903251226322632.jpg"},
               {"name":"اذاعة القران الكريم من القاهرة ","kind":_kareem,"country":"القاهرة" ,"url":"http://n08.radiojar.com/8s5u5tpdtwzuv?rj-ttl=5&rj-tok=AAABh1baiJ4AmmieGJzKDDWHRQ","logo":"https://img.youm7.com/large/201903251226322632.jpg"},
               {"name":"إذاعة حياة اف ام للقران الكريم بث ","kind":_kareem,"country":"الأردن" ,"url":"https://is.gd/OYdVmh","logo":"https://img.youm7.com/large/201903251226322632.jpg"},
               {"name":"إذاعة القرآن الكريم أبو ظبي ","kind":_kareem,"country":"الإِمَارات " ,"url":"https://is.gd/C2UNHO","logo":"https://img.youm7.com/large/201903251226322632.jpg"},
                {"name":"اذاعة القران الكريم السعودية","kind":satellite_channel,"country":"الحجاز" ,"url":"https://tinyurl.com/46mhw4h9","logo":"https://tinyurl.com/3vrsptku"},
               {"name":"إذاعة مولتيز القرآن الكريم ","kind":_kareem,"country":"" ,"url":"https://tinyurl.com/4ynvzsn4","logo":"https://img.youm7.com/large/201903251226322632.jpg"},
               ]

     return channels
